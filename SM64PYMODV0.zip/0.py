import pygame
import sys
import os
import subprocess

def main():
    # Initialize Pygame
    pygame.init()

    # Screen dimensions and title
    screen_width, screen_height = 800, 600
    screen = pygame.display.set_mode((screen_width, screen_height))

    # Colors and Fonts
    BLACK = (0, 0, 0)
    WHITE = (255, 255, 255)
    font = pygame.font.Font(None, 36)

    # Game States
    TITLE_SCREEN = 0
    FILE_SELECT = 1
    game_state = TITLE_SCREEN

    # File slots (dummy data)
    file_slots = ["File 1", "File 2", "File 3", "File 4"]
    selected_slot = 0

    # Main loop
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.KEYDOWN:
                if game_state == TITLE_SCREEN:
                    if event.key == pygame.K_RETURN:
                        game_state = FILE_SELECT
                        # Check if '1.py' exists and run it automatically
                        if os.path.isfile('1.py'):
                            subprocess.run(["python3.11", "1.py"])
                            running = False
                elif game_state == FILE_SELECT:
                    if event.key == pygame.K_UP:
                        selected_slot = (selected_slot - 1) % len(file_slots)
                    elif event.key == pygame.K_DOWN:
                        selected_slot = (selected_slot + 1) % len(file_slots)
                    elif event.key in [pygame.K_RETURN, pygame.K_z]:
                        # Execute the script '1.py' when Z or Enter is pressed
                        selected_file = file_slots[selected_slot].replace(" ", "_").lower() + ".py"
                        if os.path.isfile(selected_file):
                            subprocess.run(["python3.11", selected_file])
                            running = False

        # Fill the background
        screen.fill(BLACK)

        # Game State Rendering
        if game_state == TITLE_SCREEN:
            pygame.display.set_caption('Title Screen - Super Mario 64 Style')
            title_text = font.render('THE SHOWRUNNER: SM64 BEYOND THE UNIVERSE', True, WHITE)
            title_rect = title_text.get_rect(center=(screen_width/2, screen_height/2))
            screen.blit(title_text, title_rect)
        elif game_state == FILE_SELECT:
            pygame.display.set_caption('THE SHOWRUNNER: SM64 BEYOND THE UNIVERSE 0.1 - File Select' )
            # Render file slots
            for i, slot in enumerate(file_slots):
                if i == selected_slot:
                    label = font.render(f"> {slot}", True, WHITE)
                else:
                    label = font.render(slot, True, WHITE)
                screen.blit(label, (100, 100 + i * 40))

        # Update the display
        pygame.display.flip()

    # Quit Pygame
    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
