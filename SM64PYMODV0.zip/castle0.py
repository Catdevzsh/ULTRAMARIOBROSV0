from ursina import *

app = Ursina()

# Create the castle
castle = Entity(
    model='cube',
    texture='white_cube',  # Replace with an appropriate texture
    position=(0, 2, 0),  # Adjust the position
    scale=(5, 5, 5),  # Adjust the scale
)

# Define player controls (similar to your previous code)
def update():
    player_movement()

def player_movement():
    # Your player movement code here

    app.run()
