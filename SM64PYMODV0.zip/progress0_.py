import pygame

# Initialize Pygame
pygame.init()

# Set up the display
window_width, window_height = 800, 600
window = pygame.display.set_mode((window_width, window_height))
pygame.display.set_caption("Loading Screen Example")

# Loading bar settings
loading_bar_width, loading_bar_height = 400, 50
loading_bar_x, loading_bar_y = (window_width - loading_bar_width) // 2, (window_height - loading_bar_height) // 2
loading_progress = 0

# Colors
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)

# Font settings
font = pygame.font.Font(None, 36)
text = font.render('OVERWORLD NOW LOADING', True, WHITE)
text_rect = text.get_rect(center=(window_width//2, window_height//2 - 50))

# Game loop
running = True
while running:
    # Handle events
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    # Update the window
    window.fill((0, 0, 0))
    
    # Render the text
    window.blit(text, text_rect)

    # Update loading bar
    loading_progress += 1
    if loading_progress > 100:
        loading_progress = 100

    # Draw loading bar
    pygame.draw.rect(window, GREEN, (loading_bar_x, loading_bar_y, loading_progress * (loading_bar_width / 100), loading_bar_height))

    # Update the display
    pygame.display.flip()
    pygame.time.delay(50)  # Delay to simulate loading time

# Quit Pygame
pygame.quit()
